# Remote Server Database Information





### The remote sever uses a `GET` request with query parameters to access the database

`https://www.bridgeextra.cloud/Extra/ResultExtraAjaxServer.asp?dbName=BEX&action={parameters}`

## Database Schemas (Logical Views)

#### Q_Game_list:
*this is the list of games . you must filter and order on the date*
- **Torneo**
- **circuito**
- **swiss**
- **data**

#### Q_Game_rank:
*this is the rank of each game. you must filter on the Torneo and order by Posiz*
- **Torneo**
- **Posiz** (is the pair's ranking position.)
- **Giocatore** (code+name)
- **Giocatore1** ( code+name)
- **Media**
- **score**
- **MP2**
- **Circuito**
- **Coppia**

#### Q_Winners:

*Shows a list of the games, with the winning pair as a fields (Giocatore &  Giocatore1)*

*is the list of games with the winning pair you should filter and order on Data*
- **Circuito**  (then division)
- **Torneo**
- **Giocatore**
- **Giocatore1**
- **Media**
- **MP**
- **Data**

#### Q_Cards:
*cards from each game (you should access by Torneo)*
- **Torneo**
- **carte**
  - the cards of all the boards of the game.
for each board the first character is the declarer
1=south 2=west 3=north 4=east
then there are South, West and North cards  (East's cards must be derived by difference)

- **GIB**
  - analysis of each board (separated by crlf)
  - board number,
  - par of the hand,
  - contract: number of tricks: (suit 1=clubs, 2=diamonds, 3=hearts, 4=spades, 5=NT, delaer 1=south, 2=west , 3=north, 4=east)
  - *north*: tricks in clubs, diamonds, hearts, spades, in  NT
  - *south*: tricks in clubs, diamonds, hearts, spades, in  NT
  - *east*: tricks in clubs, in diamonds, hearts, spades, in NT
  - *West*: tricks in clubs, diamonds, hearts, spades, in NT

#### Q_Scores:
*scores of a game, (you should access by Torneo and order by Board)*
- **Torneo**
- **Board**
- **CoppiaNS**
- **CoppiaEO**
- **N_S** (punteggio)
- **E_W** (punteggio)
- **NS** (perc)
- **EW** (perc)
- **Contratto Level** | Suit | Doubled (1=doubled, 2=redoubled) | Dealer | Tricks | LeadCard (0-12 spades ARQJT98765432, 13-25 hearts, 26-38 diam, 39-51 clubs)
- **Bid**
- **PlaySeq**

#### Q_Scores_pairs:
*score of a pair. the key to access this logical view is game+posizione (position of the pair in the final ranking, i.e. the position field of the Q_Game_rank logical view)*
- **Torneo**
- **Posizione**
- **Board**
- **Turno**
- **Avversari**
- **Score**
- **Media**
- **MP**
- **PlayedAS**
- **Contratto**
- **Bid**
- **PlaySeq**


## Endpoint Request & Parameters

| Param     | Usage                 |
|-----------|-----------------------|
|`dbName`   |Always set to `BEX`    |
|`action`   |Specifies the action or query to be performed ie `q_game_list` retrieves data from `q_game_list`|
|`torneo`   |Specifies tournament. Unique identifier    |
|`dateFrom` |Filter data *from* date range   |
|`dateTo`   |Filter data *to* date range   |
|`Posiz`    |Specify position of the pair in the final ranking (position field in the `Q_Game_Rank`)    |
---

## Using Parameters

### q_game_list
mandatory: dateFrom, dateTo  \
optional: Circuito

### q_game_rank
mandatory: Torneo

### q_winners
mandatory: dateFrom, dateTo  \
optional: Circuito

### q_hand_cards
mandatory: Torneo

### q_scores
mandatory: Torneo  \
optional: Board

### q_scores_pairs
mandatory: Torneo, Posiz

### Actions *vs* Logical Views
There is a distinct difference between actions (lowercase) and the logical views (uppercase) in the context of these requests.

#### Actions (*lowercase*)
- Actions, such as `q_game_list`, `q_winners`, `q_game_rank`, etc., are used to *request* specific information or *perform* operations on the data. They act as commands to the system, indicating what kind of data you want to retrieve or what action you want to take.

#### Logical Views (*uppercase*)
- Logical views, such as `Q_Game_list`, `Q_Winners`, `Q_Game_rank`, etc., represent *predefined* structured views or queries on the *underlying* database tables. These views organize and present the data in a specific way, often combining information from multiple tables to provide a coherent and useful perspective.


For example, we might use the action `q_game_list` to request data from the logical view `Q_Game_list`, which contains a structured list of games. Similarly, actions like `q_winners` and `q_game_rank` interact with the logical views `Q_Winners` and `Q_Game_rank`, respectively, to retrieve information about winners and game rankings.

---

### Request & Response Examples

```
https://www.bridgeextra.cloud//Extra/ResultExtraAjaxServer.asp?dbName=BEX&action=q_game_list&dateFrom=2024-02-20&dateTo=2024-02-23

[{
        "torneo": "2024-02-20 #32690 Pairs MEDITERRANEO",
        "circuito": "ibex_22",
        "Swiss": "N",
        "Data": "2024-02-20"
    }, {
        "torneo": "2024-02-21 #39481 Pairs MEDITERRANEO",
        "circuito": "ibex_22",
        "Swiss": "N",
        "Data": "2024-02-21"
    }
]

```

```
https://www.bridgeextra.cloud//Extra/ResultExtraAjaxServer.asp?dbName=BEX&action=q_winners&dateFrom=2024-02-20&dateTo=2024-02-23

[{
        "Circuito": "ibex_22",
        "Torneo": "2024-02-20 #32690 Pairs MEDITERRANEO",
        "Giocatore": "Minus4000-Ray Clarke",
        "Giocatore1": "jaray18-Minus4000",
        "Media": "60.76",
        "MP": "1.3",
        "Data": "2024-02-20"
    }, {
        "Circuito": "ibex_22",
        "Torneo": "2024-02-21 #39481 Pairs MEDITERRANEO",
        "Giocatore": "jordimd9-ramon53",
        "Giocatore1": "ramon53-jordimd9",
        "Media": "70.06",
        "MP": "1.2",
        "Data": "2024-02-21"
    }
]
```

```
https://www.bridgeextra.cloud//Extra/ResultExtraAjaxServer.asp?dbName=BEX&action=q_game_rank&torneo=2024-02-20%20%2332690%20Pairs%20MEDITERRANEO

[{
        "Torneo": "2024-02-20 #32690 Pairs MEDITERRANEO",
        "Posiz": "1",
        "Giocatore": "Minus4000-Minus4000",
        "Giocatore1": "jaray18-Ray Clarke",
        "Media": "60.76",
        "Score": "0",
        "MP2": "1.30 ",
        "Circuito": "ibex_22",
        "Coppia": "1"
    }, {
        "Torneo": "2024-02-20 #32690 Pairs MEDITERRANEO",
        "Posiz": "2",
        "Giocatore": "Robot-Advanced Robot",
        "Giocatore1": "Bearish-Bearish",
        "Media": "59.9",
        "Score": "0",
        "MP2": "0.91 ",
        "Circuito": "ibex_22",
        "Coppia": "2"
    }, {...
    }
]
```

```
https://www.bridgeextra.cloud//Extra/ResultExtraAjaxServer.asp?dbName=BEX&action=q_hand_cards&torneo=2024-02-20%20%2332690%20Pairs%20MEDITERRANEO

[{
        "torneo": "2024-02-20 #32690 Pairs MEDITERRANEO",
        "carte": "|rvrs||qx|o1|Board 1|md|3S45678H79DAC347KA,S23KHTD247JC289TJ,SH2358JKAD568TQKC,|qx|o2|Board 2|md|4S9TQAH237D24KAC8Q,S468HTJD56TC249TA,S25H69QKAD8JQC57J,|qx|o3|Board 3|md|1S456TH259QD39C23T,S29KH36TJAD4KC689,S78QH48KD256TJC7A,|qx|o4|Board 4|md|2S3TQH3QAD79C389TQ,S29H49KD3TQAC67KA,S56JH568TD68C245J,|qx|o5|Board 5|md|3SH9QKAD79KAC7TQKA,S39QH256JD38TQC8J,S48TJH78TD56C2345,|qx|o6|Board 6|md|4S69H35689D456TCJK,S458AH7JD28C2348A,S2TH2TQKAD37AC569,|qx|o7|Board 7|md|1S6789JH7TKDTC2569,S34QH23JADQAC478A,S5KH458D459KCTJQK,|qx|o8|Board 8|md|2S69H468D79JQC478Q,S58TH2JQKD4AC35TK,S4QKAH5TD28TKC6JA,|qx|o9|Board 9|md|3S59H458JKAD67C4TQ,S78TJKH9TD4KAC239,S36HD2359TJQC68JA,|qx|o10|Board 10|md|4S37H9TD2348QC26KA,S569JH2JQKAD9C35J,S2KAH4567DJAC479Q,|qx|o11|Board 11|md|1S7H3567JD24TQC3QA,S256QAH29AD6C2568,S39TJH8TQDJAC4TJK,|qx|o12|Board 12|md|2S27TKH25D48QKC34A,S89QAH8JQD237C259,S3456JH3KADJC67TJ,|qx|o13|Board 13|md|3S23459H279KAD3TC5,SH348TJD28JC249JA,S68TQKAH6DAC367QK,|qx|o14|Board 14|md|4S2TKH347AD2QC78JA,S89QH25JQD68TC5TK,S457JAH89TD49C46Q,|qx|o15|Board 15|md|1S279KH5D358QC356Q,S5TJAH234TD249TKC,S346QH7D67JC27TJK,|qx|o16|Board 16|md|2S347TH2AD9JQKC29Q,S29QKH467KD7TACTA,S5AH3589JQD34C678,|qx|o17|Board 17|md|3SJKAHTJQD2789AC35,S359TQH456DTJC27J,S47H3789AD345C6TQ,|qx|o18|Board 18|md|4STKH67JDC45678TJQ,S35JH8TQKD239TKC9,S789QH25AD4567QCK,|qx|o19|Board 19|md|1STKAH69AD28QKC237,S3459QH78KD9JC4TA,S26JH23TD56AC68JK,|qx|o20|Board 20|md|2S3TQH8JD2459QC4TQ,S6JH7TKD8TKC267JK,S2457KAH245DC358A,|qx|o21|Board 21|md|3S6H35678QD7QC245J,S348JH49JAD36C7TK,S27KAHTD459TJKC3Q,|qx|o22|Board 22|md|4S5AH4QKAD268QAC89,S23JKH6TD79C246JQ,S789QH579D5TKC37K,|qx|o23|Board 23|md|1S89JH3AD3489TJKCA,S357TKH6D25C238TQ,S246H489QKD67QC4J,|qx|o24|Board 24|md|2S456QH35JD69AC3TJ,S2AH2QD2578TC26QA,S7H89TKD34QC45789,|",
        "GIB": "1 980 6 3 1 5 11 12 4 7 5 11 12 4 7 7 2 1 7 6 7 2 1 7 6 2 660 3 5 1 9 11 11 10 11 9 11 11 10 11 4 0 1 2 1 4 0 1 2 1 3 -660 3 5 3 2 3 3 3 2 2 3 3 3 2 11 9 10 9 11 11 10 10 9 11 4 -1370 6 2 3 5 1 3 2 2 5 1 3 2 2 8 12 10 11 11 8 12 10 11 11 5 1370 6 1 1 12 9 10 7 10 12 9 10 7 10 1 4 1 6 3 1 4 1 6 3 6 -500 5 3 1 4 6 8 3 6 4 6 8 3 6 9 7 5 10 6 9 7 5 10 6 7 -140 1 3 3 6 3 3 5 5 6 3 3 5 5 6 10 9 8 8 6 10 9 8 8 8 120 2 5 1 8 9 6 7 8 8 9 6 7 8 5 4 7 5 5 5 4 7 5 5 9 -500 5 2 1 6 8 6 3 5 6 8 6 3 5 5 3 7 10 8 5 5 7 10 8 10 110 3 1 1 9 8 6 5 7 9 8 6 5 7 4 5 6 8 6 4 5 6 8 6 11 100 3 4 3 7 5 9 5 6 7 5 9 5 6 6 7 4 8 6 6 7 4 8 6 12 140 3 4 1 8 6 6 9 6 8 6 5 9 6 5 7 7 4 6 5 7 7 4 7 13 1100 7 2 3 9 4 8 12 9 9 4 8 12 9 4 9 4 1 3 4 9 4 1 3 14 100 3 2 3 8 4 7 8 7 8 4 7 8 7 4 8 6 4 6 4 8 6 4 6 15 -1510 7 3 3 6 3 0 4 2 6 3 0 4 2 7 9 13 7 11 7 9 13 7 11 16 -110 2 4 3 3 5 7 4 4 4 5 7 4 6 7 8 5 8 7 7 8 5 8 7 17 -100 2 5 1 5 8 8 4 7 5 8 8 4 7 8 5 5 8 6 8 5 5 8 6 18 -200 4 1 1 9 4 4 4 4 9 4 4 4 4 4 9 9 8 9 4 9 8 8 9 19 120 1 5 1 8 8 7 7 8 8 8 8 7 8 4 5 5 6 4 4 5 5 6 4 20 140 3 4 1 6 4 4 9 4 6 4 4 9 4 7 9 8 4 6 7 9 9 4 6 21 -140 1 4 3 5 7 6 4 6 5 7 6 4 6 7 5 7 9 6 7 5 7 9 6 22 400 3 5 1 6 10 9 8 9 6 10 9 8 9 7 3 4 5 3 7 3 4 5 3 23 -600 5 1 3 2 8 6 3 4 2 8 6 3 4 11 3 6 9 3 11 3 6 9 3 24 -420 4 4 3 6 3 5 3 4 6 3 5 3 4 7 9 8 10 8 7 10 8 10 8 "
    }
]

```

```
https://www.bridgeextra.cloud//Extra/ResultExtraAjaxServer.asp?dbName=BEX&action=q_scores&torneo=2024-02-20%20%2332690%20Pairs%20MEDITERRANEO

[{
        "Torneo": "2024-02-20 #32690 Pairs MEDITERRANEO",
        "Board": "1",
        "CoppiaNS": "11 19lane20 - jmm72",
        "CoppiaEO": "9 shooner - UGAL",
        "N_S": "980",
        "E_W": "",
        "NS": "87.5",
        "EW": "12.5",
        "Contratto": "6|1|0|0|12|0",
        "Bid": "2C 2S 3C - 3H - 4N - 5H - 6H - - -",
        "PlaySeq": "SA.S4.S3.H2.D5.D9.DA.D2.CA.C2.D6.C5.CK.C8.D8.C6.S5.S2.H3.S9.DT.D3.H7.D4.H9.HT.HA.H4.HK.H6.C3.C9.HJ.HQ.C4.D7.SQ.S6.SK.H5.H8.ST.S7.CJ.DK.SJ.C7.DJ.DQ.CQ.S8.CT"
    }, {
        "Torneo": "2024-02-20 #32690 Pairs MEDITERRANEO",
        "Board": "1",
        "CoppiaNS": "10 barna58 - titapas",
        "CoppiaEO": "6 2wisky - Advanced Robot",
        "N_S": "980",
        "E_W": "",
        "NS": "87.5",
        "EW": "12.5",
        "Contratto": "6|1|0|0|12|31",
        "Bid": "2C - 2D - 4H - 6H - - -",
        "PlaySeq": "D9.DA.D2.D5.CA.C2.D6.C5.CK.C8.D8.C6.S4.S2.H2.SQ.HA.H4.H7.HT.HK.H6.H9.S3.H3.HQ.C3.C9.SJ.S5.SK.H5.HJ.D3.S6.D4.H8.CQ.C4.CJ.DK.SA.C7.D7.DQ.S9.S7.DJ.DT.ST.S8.CT"
    }, { ...
   }
]
```

```
https://www.bridgeextra.cloud//Extra/ResultExtraAjaxServer.asp?dbName=BEX&action=q_scores_pairs&torneo=2024-02-20%20%2332690%20Pairs%20MEDITERRANEO&Posiz=2

[{
        "Torneo": "2024-02-20 #32690 Pairs MEDITERRANEO",
        "Posizione": "2",
        "Board": "9",
        "Turno": "2",
        "Avversari": "shooner - UGAL",
        "Score": "300",
        "Media": "100",
        "MP": "",
        "PlayedAS": "NS",
        "Contratto": "3|1|0|1|6|33",
        "Bid": "3D° 3H - - -",
        "PlaySeq": "D7.DA.D5.D8.DK.D3.C5.D6.D4.D9.H2.H4.S9.S7.S3.SA.S2.S5.ST.S6.H9.C8.H3.HJ.C4.C2.CA.C7.C6.CK.CT.C3.H6.HK.HT.CJ.CQ.C9.DQ.H7.SQ.H5.S8.DJ.HA.SJ.DT.HQ.H8.SK.D2.S4"
    }, {
        "Torneo": "2024-02-20 #32690 Pairs MEDITERRANEO",
        "Posizione": "2",
        "Board": "7",
        "Turno": "2",
        "Avversari": "Advanced Robot - golfrap22",
        "Score": "500",
        "Media": "100",
        "MP": "",
        "PlayedAS": "NS",
        "Contratto": "3|4|1|3|7|40",
        "Bid": "- 1N° - 3C!° - 3N° - - *° - - -",
        "PlaySeq": "CK.C3.C2.CA.HJ.H4.H6.HK.C9.C4.CT.D2.CQ.D3.C6.C7.CJ.S2.C5.C8.H8.HQ.H7.H2.D6.DT.DQ.DK.SK.SA.S6.S3.D7.S7.DA.D4.SQ.S5.ST.SJ.HA.H5.H9.HT.H3.D5.D8.S9.S4.D9.DJ.S8"
    }, { ...
    }
]
```

