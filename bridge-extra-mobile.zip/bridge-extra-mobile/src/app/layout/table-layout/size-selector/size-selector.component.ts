import { Component } from '@angular/core';

@Component({
  selector: 'app-size-selector',
  standalone: true,
  imports: [],
  templateUrl: './size-selector.component.html',
  styleUrl: './size-selector.component.scss'
})
export class SizeSelectorComponent {

}
