import { Component } from '@angular/core';

@Component({
  selector: 'app-player-games',
  standalone: true,
  imports: [],
  templateUrl: './player-games.component.html',
  styleUrl: './player-games.component.scss'
})
export class PlayerGamesComponent {

}
