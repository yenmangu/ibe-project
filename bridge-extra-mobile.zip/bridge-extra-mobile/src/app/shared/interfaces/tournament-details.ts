export interface TournamentDetails {
	Torneo: string;
	Posiz: string;
	Giocatore: string;
	Giocatore1: string;
	Media: string;
	score: string;
	MP2: string;
	Circuito: string;
	Coppia: string;
}
