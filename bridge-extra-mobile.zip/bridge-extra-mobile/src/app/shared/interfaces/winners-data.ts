export interface WinnersData {
	Circuito: string;
	Torneo: string;
	Giocatore: string;
	Giocatore1: string;
	Media: any;
	MP: any;
	Data: any;
}
