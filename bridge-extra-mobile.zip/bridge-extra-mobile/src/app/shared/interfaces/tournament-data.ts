export interface Tournament {
	torneo: string;
	circuito: string;
	Swiss: string;
	Data: string;
}
