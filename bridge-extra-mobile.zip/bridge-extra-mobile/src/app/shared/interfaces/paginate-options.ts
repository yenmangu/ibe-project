export enum PaginateOption {
	Prev = 'prev',
	Reset = 'reset',
	Next = 'next'
}
