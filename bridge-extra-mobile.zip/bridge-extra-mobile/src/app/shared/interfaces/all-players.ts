export interface AllPlayersInterface {
	posizione: number;
	codice: string;
	Player: string;
	torneo: string;
	media: number;
	circuito: string;
	datatorneo: string;
	temp: string;
	swiss: string;
}
