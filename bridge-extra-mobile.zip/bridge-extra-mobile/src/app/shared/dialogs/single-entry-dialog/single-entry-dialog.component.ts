import { Component } from '@angular/core';

@Component({
  selector: 'app-single-entry-dialog',
  standalone: true,
  imports: [],
  templateUrl: './single-entry-dialog.component.html',
  styleUrl: './single-entry-dialog.component.scss'
})
export class SingleEntryDialogComponent {

}
