import { MapHeadersPipe } from './map-headers.pipe';

describe('MapHeadersPipe', () => {
  it('create an instance', () => {
    const pipe = new MapHeadersPipe();
    expect(pipe).toBeTruthy();
  });
});
