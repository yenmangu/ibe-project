import { RemovePlayerCodePipe } from './remove-player-code.pipe';

describe('RemovePlayerCodePipe', () => {
  it('create an instance', () => {
    const pipe = new RemovePlayerCodePipe();
    expect(pipe).toBeTruthy();
  });
});
