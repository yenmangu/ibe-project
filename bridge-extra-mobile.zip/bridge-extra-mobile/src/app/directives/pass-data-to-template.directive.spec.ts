import { PassDataToTemplateDirective } from './pass-data-to-template.directive';

describe('PassDataToTemplateDirective', () => {
  it('should create an instance', () => {
    const directive = new PassDataToTemplateDirective();
    expect(directive).toBeTruthy();
  });
});
