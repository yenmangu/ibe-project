import { ClickHandlerDirective } from './click-handler.directive';

describe('ClickHandlerDirective', () => {
  it('should create an instance', () => {
    const directive = new ClickHandlerDirective();
    expect(directive).toBeTruthy();
  });
});
