import { Component } from '@angular/core';

@Component({
  selector: 'app-database-landing',
  standalone: true,
  imports: [],
  templateUrl: './database-landing.component.html',
  styleUrl: './database-landing.component.scss'
})
export class DatabaseLandingComponent {

}
