export const environment = {
	API_URL: 'https://www.api.ibescore.com/results'
};
