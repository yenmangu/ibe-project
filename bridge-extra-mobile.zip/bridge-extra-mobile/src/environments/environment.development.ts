export const environment = {
	API_URL: 'http://192.168.68.100:4060/results'
};
