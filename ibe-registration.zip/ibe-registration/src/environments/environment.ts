export const environment = {
	API_URL: 'https://api.ibescore.com/ibescore',
	ORIGIN: 'https://registration.ibescore.com',
	PRODUCTION: true
};
