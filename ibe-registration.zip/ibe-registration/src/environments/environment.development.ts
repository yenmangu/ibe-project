export const environment = {
	API_URL: 'http://localhost:3030/ibescore',
	// API_URL: 'https://api.velvet-oaks.co.uk/ibescore',
	ORIGIN: 'http://localhost:4200',
	PRODUCTION: false
};
