export interface RegistrationForm {
	first_name: string;
	last_name: string;
	type: string;
	email: string;
	tel_phone: string;
	password: string;
	password_confirm: string;
	country: string;
	slot: string;
	dialingCode: string;
	city: string;
	usage: string;
	comments: string;
	howHeard: string;
	feedback: string;
}
