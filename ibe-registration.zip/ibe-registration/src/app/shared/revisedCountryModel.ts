export interface RevisedCountryModel {
	name: string;
	dial_code: string;
	emoji: string;
	alphaCode: string;
}
