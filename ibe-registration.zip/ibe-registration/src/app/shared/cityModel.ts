export interface CityModel {
	country: string;
	name: string;
	lat: string;
	lng: string;
}
