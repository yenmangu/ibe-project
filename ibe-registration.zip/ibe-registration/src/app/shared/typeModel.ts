export interface AccountType {
	name: string;
	message: string;
	typeCode: string;
}
