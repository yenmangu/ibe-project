export interface UsageModel {
	value: string;
	label: string;
	checked: boolean;
}
