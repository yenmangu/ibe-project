export interface FeedbackModel {
	message: string,
	value: string,
}