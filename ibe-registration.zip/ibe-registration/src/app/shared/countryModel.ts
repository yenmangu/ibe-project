export interface Country {
	code: string
	code3: string
	name: string
	number: string
}