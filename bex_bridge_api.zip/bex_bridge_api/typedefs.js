//@ts-check

/**
 * @namespace typedefs
 */

/**
 * @exports PoolConnection
 * @typedef {import('mysql2/promise').PoolConnection} PoolConnection
 * @type {Promise}
 *
 *
 */
import mysql from 'mysql2/promise';

const { createConnection } = mysql;

/**
 *
 * @typedef {import('mysql2/promise').PoolConnection} MySqlConnection
 * @typedef {import('mysql2/promise').Pool} MySqlPool
 */

export default { MySqlConnection, MySqlPool };
