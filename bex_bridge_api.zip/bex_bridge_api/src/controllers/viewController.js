import qGameList from '../models/qGameList.js';
import qGameRank from '../models/qGameRank.js';
import qScores from '../models/qScores.js';
import qPairScore from '../models/qPairScore.js';
import qWinners from '../models/qWinners.js';
import qGamesPlayers from '../models/qGamesPlayers.js';
import qGeneralRecap from '../models/qGeneralRecap.js';
import qGamesRecap from '../models/qGamesRecap.js';
import qPartnersRecap from '../models/qPartnersRecap.js';
import qMonthRecap from '../models/qMonthRecap.js';
import catchAsync from '../utils/catchAsync.js';
import monthRecapQuery from '../services/queryStrings/monthRecap.js';
import generalRecapQuery from '../services/queryStrings/generalRecap.js';
import partnersRecapQuery from '../services/queryStrings/partnersRecap.js';

function getView(viewString) {
	switch (viewString) {
		case 'qScores':
			return qScores;
		case 'qGameList':
			return qGameList;
		case 'qGameRank':
			return qGameRank;
		case 'qPairScore':
			return qPairScore;
		case 'qWinners':
			return qWinners;
		case 'qGamesPlayers':
			return qGamesPlayers;
		case 'qGeneralRecap':
			return qGeneralRecap;
		case 'qGamesRecap':
			return qGamesRecap;
		case 'qPartnersRecap':
			return qPartnersRecap;
		case 'qMonthRecap':
			return qMonthRecap;
	}
}

export const viewController = catchAsync(async (req, res, next) => {
	try {
		// console.log('Req query: ', req.query);
		const query = req.query;

		const { view, all, limit, offset, explain } = query;
		if (!view) {
			return res.status(400).json({ status: 'fail', message: 'No view in query' });
		}
		if (explain) {
			viewFunc.explain();
		}
		const viewModel = getView(view);
		let data;

		let playerArray;
		let playerName;
		let playerCode;
		if (query.player) {
			playerArray = extractPlayerCode(query.player);
			playerCode = playerArray[0];
			playerName = playerArray[1];
		}

		// console.log('Player Name: ', playerName);
		// console.log('Player Code: ', playerCode);
		// console.log('Veiw Model: ', viewModel);

		let options;
		if (limit) {
			options = { limit: limit };
		} else {
			options = null;
		}

		if (viewModel === qGameRank || viewModel === qScores) {
			console.log('View is: ', view);

			const tournament = query.torneo;
			data = await viewModel.findAll({ torneo: tournament }, null, null, null);
		} else if (viewModel === qGamesPlayers) {
			console.log('QGamesPlayers');
			if (query.player) {
				data = await viewModel.findOne({ codice: playerCode });
				// return res.status(200).json({ status: 'success' });
			} else {
				data = await viewModel.findAll(null, null, null, options);
			}
		} else if (viewModel === qGamesRecap) {
			data = await viewModel.findAll({ codice: playerCode });
		} else if (
			viewModel === qGeneralRecap ||
			viewModel === qMonthRecap ||
			viewModel === qPartnersRecap
		) {
			if (!query.player) {
				return res
					.status(400)
					.json({ status: 'fail', message: 'No player in query' });
			}
			// data = await viewModel.findAll({ codice: playerCode });
			viewModel === qMonthRecap
				? (data = await getMonthRecap(playerCode))
				: viewModel === qGeneralRecap
				? (data = await getGeneralRecap(playerCode))
				: viewModel === qPartnersRecap
				? (data = await getPartnersRecap(playerCode))
				: (data = {});
		} else {
			console.log('Reached else block. View: ', view);

			data = await viewModel.findAll(null, null, undefined, options);
		}

		res
			.status(200)
			.json({ status: 'success', meta: explain ? data[0] : '', data: data });
	} catch (error) {
		return next(error);
	}
});

function extractPlayerCode(combined) {
	let arr = combined.split('-');
	arr.map(e => e.trim());
	return arr;
}

export const gameScoresController = catchAsync(async (req, res, next) => {
	try {
		const { view, limit, offset, explain } = req.query;

		if (!view) {
			return res.status(400).json({ status: 'fail', message: 'No view in query' });
		}
		const viewModel = getView(view);
		if (req.query.torneo) {
			const tournament = req.query.torneo;
			const data = await viewModel.findAll(null, null, { torneo: tournament });
			res.sattus(200).json({ status: 'success', data: data });
		}
	} catch (error) {
		return next(error);
	}
});

async function getMonthRecap(player) {
	try {
		const queryString = monthRecapQuery();

		const response = await qMonthRecap.useQueryString(queryString, [player]);

		return response;
	} catch (error) {
		throw error;
	}
}

async function getGeneralRecap(player) {
	try {
		const queryString = generalRecapQuery();
		const response = await qGeneralRecap.useQueryString(queryString, [
			player,
			player
		]);
		/**
		 * Uncomment below for dev/debugging
		 */
		// const explain = `EXPLAIN ${queryString}`;
		// const explainResponse = await qGeneralRecap.useQueryString(explain, [
		// 	player,
		// 	player
		// ]);
		// console.log('Explain Response: ', explainResponse);
		return response;
		// return explainResponse;
	} catch (error) {
		throw error;
	}
}

async function getPartnersRecap(player) {
	try {
		const showCategory = true;
		const queryString = partnersRecapQuery(showCategory);
		const response = await qPartnersRecap.useQueryString(queryString, [
			// player,
			player
		]);
		return response;
	} catch (error) {
		throw error;
	}
}

export default { viewController, gameScoresController };
