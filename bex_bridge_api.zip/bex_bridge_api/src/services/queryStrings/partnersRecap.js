function partnersRecapQuery(showCategory) {
	let tmp = "CONCAT(T2.Codice, '-', T2.Giocatore)";
	let query = `SELECT ${tmp} AS Giocatore, `;

	// If showCategory is false, we omit the Categoria field from the query
	if (!showCategory) {
		query += 'COUNT(T2.Torneo) AS Tornei, ';
		query += 'SUM(T2.Punteggio) AS Punti, ';
		query += 'ROUND(AVG(T2.Media * 100) / 100, 2) AS Media, ';
		query += 'SUM(T2.PuntiFib) AS FIGB ';
	} else {
		// If showCategory is true, we include the Categoria field in the query
		query += 'MIN(T2.Categoria) AS Cat, ';
		query += 'COUNT(T2.Torneo) AS Tornei, ';
		query += 'SUM(T2.Punteggio) AS Punti, ';
		query += 'ROUND(AVG(T2.Media * 100) / 100, 2) AS Media, ';
		query += 'SUM(T2.PuntiFib) AS FIGB ';
	}

	query += 'FROM Tornei T1 INNER JOIN Tornei T2 ';
	query += 'ON T1.Torneo = T2.Torneo ';
	query += 'AND T1.Posizione = T2.Posizione ';
	query += 'AND T1.Giocatore <> T2.Giocatore ';
	query += 'WHERE T1.Codice = ? ';
	query += `GROUP BY ${tmp}`;

	return query;
}

export default partnersRecapQuery;
