function generalRecapQuery() {
	let query = 'SELECT Circuito, ';
	query += 'COUNT(Torneo) AS Tornei, ';
	query += 'SUM(Punteggio) AS Punti, ';
	query += 'ROUND(AVG(Media * 100) / 100, 2) AS Media, ';
	query += 'SUM(PuntiFib) AS FIGB ';
	query += 'FROM Tornei ';
	query += 'WHERE Codice = ? ';
	query += 'GROUP BY Circuito ';
	query += 'UNION ';
	query += "SELECT '0- All Divisions' AS Circuito, ";
	query += 'COUNT(Torneo) AS Tornei, ';
	query += 'SUM(Punteggio) AS Punti, ';
	query += 'ROUND(AVG(Media * 100) / 100, 2) AS Media, ';
	query += 'SUM(PuntiFib) AS FIGB ';
	query += 'FROM Tornei ';
	query += 'WHERE Codice = ?';

	return query;
}

export default generalRecapQuery;
