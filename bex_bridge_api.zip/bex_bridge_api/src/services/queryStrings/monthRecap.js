function monthRecapQuery() {
	let query = 'SELECT DATA, ';
	query += 'COUNT(*) AS TotalEvents, ';
	query += 'SUM(puntiFIB) AS MPTotal, ';
	query += 'SUM(numPair) AS PairEvents, ';
	query += 'SUM(MpPair) AS MPPair, ';
	query += 'ROUND(AVG(avgPair), 1) AS PctPair, ';
	query += 'SUM(numTeam) AS TeamEvents, ';
	query += 'SUM(MpTeam) AS MPTeams ';
	query += 'FROM (';
	query += "SELECT DATE_FORMAT(DataTorneo, '%Y-%m %M') AS Data, puntiFIB, ";
	query += "CASE WHEN Swiss = 'Y' THEN 1 ELSE NULL END AS numTeam, ";
	query += "CASE WHEN Swiss = 'Y' THEN puntiFIB ELSE NULL END AS MpTeam, ";
	query += "CASE WHEN Swiss <> 'Y' THEN 1 ELSE NULL END AS numPair, ";
	query += "CASE WHEN Swiss <> 'Y' THEN puntiFIB ELSE NULL END AS MpPair, ";
	query += "CASE WHEN Swiss <> 'Y' THEN Media ELSE NULL END AS avgPair ";
	query += 'FROM Tornei ';
	query += 'WHERE Codice = ?) AS x ';
	query += 'GROUP BY x.Data ';
	query += 'ORDER BY x.Data DESC';

	return query;
}

export default monthRecapQuery;
