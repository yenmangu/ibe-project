const bcrypt = require('bcryptjs');
const saltChars =
	'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789$%^&*()-_+=~';

// const salt = bcrypt.genSaltSync(10, { charset: saltChars });
const saltRounds = 10;
const salt = bcrypt.genSaltSync(saltRounds, saltChars);

function generateHash(inputString) {
	return bcrypt.hashSync(inputString, salt);
}

const hash = generateHash('puma');
console.log('\n',hash);

const inputPassword = 'puma';
const newHash = '$2a$10$mqdAs09FCmklFGq8nESfSev6J9l3iriRc6H1MgVwJYhDFfKD7K8Uu'

const isValid = bcrypt.compareSync(inputPassword, newHash);

isValid ? console.log('true') : console.log('false');
