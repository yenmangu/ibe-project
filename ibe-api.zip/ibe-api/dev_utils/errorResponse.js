const successString = 'message = Upload Successful\nevent = 20230709_1';
const bwFailString = 'message = ERROR - Invalid Password nicole';
const victorFail = 'nofile';

const testData = victorFail;

function getBridgeWebsResult(serverResponse) {
	const array = serverResponse.split('\n');
	let responseObject = { success: false };
	let errorArray = [];
	const firstLine = array[0].toLowerCase();
	if (firstLine === 'failure') {
		if (array[1] !== '' || array[1] !== undefined) {
			errorArray.push(array[1]);
		} else {
			errorArray.push('Unknown error from remote server');
		}
	} else if (firstLine !== 'failure') {
		errorArray.push();
	} else if (array[0].split(' ')[0].toLowerCase() !== 'message') {
		errorArray.push('Unknown error from remote server');
	} else {
		const resultArray = array[0].split(' ');
		resultArray.forEach(el => {
			if (el.toLowerCase() === 'error') {
				errorArray.push(array[0]);
			}
			if (el.toLowerCase() === 'successful') {
				responseObject.success = true;
				return responseObject;
			}
		});
	}
	responseObject.error = errorArray;
	return responseObject;
}

function e(serverResponse) {
	const responseArray = serverResponse.split('\n');
	const firstLine = typeof responseArray[0] === 'string' ? responseArray[0] : '';
	const secondLine = typeof responseArray[1] === 'string' ? responseArray[1] : '';
	const errorArray = [];
	const messageInitiater = 'message';
	let errorString = '';
	let responseObject = { success: false };

	if (firstLine === '') {
	}
	if (
		firstLine.toLowerCase() !== 'failure' ||
		firstLine.toLowerCase() !== 'message'
	) {
		errorString = 'Unknown failure from remote server';
		errorArray.push(errorString);
	}
	if (firstLine.toLowerCase() === 'failure') {
		errorString = secondLine;
		errorArray.push(errorString);
	}

	if (firstLine.toLowerCase().startsWith(messageInitiater)) {
		console.log('In message branch');
		const messageString = firstLine.split(' ');
	}
}

// const result = getBridgeWebsResult(testData);

// console.log(result);

let responseObject = {
	success: false,
	// error: undefined || [''],
	message: ''
};

// console.log(responseObjec.length);
