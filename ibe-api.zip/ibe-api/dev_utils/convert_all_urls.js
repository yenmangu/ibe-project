const linSheetsController = require('../src/controllers/google_controllers/lin_sheets_controller');
const createAuthClient = require('../src/controllers/google_controllers/service_account_auth_controller');
const { use } = require('../src/routes/webhook');
const { convertURL } = require('../src/services/url_string_extraction');
const SPREADSHEET_ID = '1l9PQUVd66IQlkr24sjuJjvFeX14acbc7S_k6dpIPFXo';
const tabName = 'webhook_test';
const lookupTab = 'BBO';
const modifiedDataTab = 'converted_lin';
const newTab = 'new_lin';

async function processURLS() {
	try {
		const MAX_RETRIES = 5; // Set the maximum number of retries
		const BASE_DELAY_MS = 1000; // Set the base delay time (1 second)
		const MAX_DELAY_MS = 60000; // Set the maximum delay time (1 minute)
		let retries = 0;

		async function makeRequest() {
			const authClient = await createAuthClient();
			const sheets = await linSheetsController.sheetsAuthClient();
			try {
				const response = await sheets.spreadsheets.values.get({
					spreadsheetId: SPREADSHEET_ID,
					range: `${lookupTab}!A:L`,
					auth: authClient
				});

				const values = response.data.values;
				const processedData = [];

				if (Array.isArray(values) && values.length > 1) {
					const headerRow = values[0];
					const dataToProcess = values.slice(1);

					for (const row of dataToProcess) {
						const URL = row[1];
						const ID = row[11];

						console.log('processing: ', ID);
						const useableString = convertURL(URL);
						processedData.push([ID, useableString, URL]);
						// const rowData = [ID, useableString];

						console.log('finished ID: ', ID);
					}

					const response = await sheets.spreadsheets.values.get({
						spreadsheetId: SPREADSHEET_ID,
						range: `${newTab}`
					});
					const firstEmptyRow = response.data.values
						? response.data.values.length + 1
						: 0;
					try {
						await sheets.spreadsheets.values.update({
							spreadsheetId: SPREADSHEET_ID,
							range: `${newTab}!A${firstEmptyRow}`,
							valueInputOption: 'USER_ENTERED',
							resource: {
								values: processedData
							},
							auth: authClient
						});
						processedData.length = 0;
					} catch (err) {
						console.error(err);
						return;
					}
				} else {
					console.error('No data to process or unexpected data structure');
				}
			} catch (err) {
				console.error('Request Error: ', err);

				if (err.response && err.response.status === 429) {
					console.log(
						'Hitting max request limit. Pausing for 1 minute before resuming'
					);
					await new Promise(resolve => setTimeout(resolve, 60000));
				} else {
					if (retries < MAX_RETRIES) {
						retries++;

						const delay = Math.min(BASE_DELAY_MS * 2 ** retries, MAX_DELAY_MS);
						console.log(`Retrying in ${delay / 1000} seconds...`);
						await new Promise(resolve => setTimeout(resolve, delay));

						// Continue to the next iteration of the loop
						return makeRequest();
					} else {
						console.error('Max retries reached. Request failed');
					}
				}
			}
		}

		await makeRequest();
		console.log('Data Processed and added');
	} catch (err) {
		console.error('Uh Oh', err);
	}
}

processURLS();
