const names = [
	'Helen Bertels & Liz Whittaker\nGraeme Monk & Roz Montague\nAlan Smith & Kei Miyakita\nAlan Walker & Joy Wright\nJosie Silver & Isabel Param\nDavid Rothberg & Patsy Berry\nTerry Mitchell & Jean Pearce\nRobert Flood & Monica Grott\nBarbara Clark & Roger Whittaker\nChris Simmons & Bob McMahon\nAlan Featherstone & Chris Briggs\nSharon Walker & Sheila Boniface\nJosie Dickson & Siva Param\nDemetrios Souppouris & Lynda Morris\nSteve Goldman & Brenda Blackwell\nFaye Bray & Linda Jackson\n'
];

function processNames(names, numOfTables) {
	const namesInPlay = numOfTables * 2;

	let namesArray = [];
	const lines = names[0].split('\n').filter(line => line.trim() !== '');
	console.log('lines: ', lines);

	const splitIndex = Math.ceil(lines.length / 2);
	namesArray = namesInPlay !== -1 ? lines.slice(0, namesInPlay) : lines;
	console.log('namesArray: ', namesArray);

	namesArray = namesArray.map(item => item.split(' & '));

	console.log('namesArray: ', namesArray);

	console.log('split index: ', splitIndex);
	const firstHalf = namesArray.slice(0, splitIndex);
	const secondHalf = namesArray.slice(splitIndex);

	console.log(firstHalf);
	console.log(secondHalf);
	let newArray = [];
	for (let i = 0; i < firstHalf.length; i++) {
		newArray.push(firstHalf[i]);
		newArray.push(secondHalf[i]);
	}
	console.log('new array: ', newArray);
}

processNames(names,8);
