const linSheetsController = require('../src/controllers/google_controllers/lin_sheets_controller');

const string = 'https://www.bridgebase.com/tools/handviewer.html?lin=st||pn|Dijous,feucha,nuvol,nemiera|md|1SKQ7HKJT73D3C6543,SAT532H92DAKQ5CA7,S986HQ4DT8CKQJT82,SJ4HA865DJ97642C9|sv|e|rh||ah|Board3|mb|P|mb|1S|mb|P|mb|1N|an|Forcing|mb|2H|mb|3D|mb|P|mb|P|mb|P|pc|HQ|pc|HA|pc|H7|pc|H2|pc|D2|pc|D3|pc|DA|pc|D8|pc|DK|pc|DT|pc|D4|pc|C3|pc|CA|pc|C2|pc|C9|pc|C4|pc|S2|pc|S6|pc|SJ|pc|SQ|pc|HK|pc|H9|pc|H4|pc|H5|pc|HJ|pc|D5|pc|C8|pc|H6|pc|SA|pc|S8|pc|S4|pc|S7|pc|C7|pc|CT|pc|D6|pc|C5|pc|H8|pc|HT|pc|DQ|pc|S9|mc|11|';
const expected = '4501';

function checkIDRetrieval(id) {
	const retrievedId = linSheetsController.getId(string);
	if (retrievedId.toString() === expected.toString()) {
		console.log('success');
		console.log('id: ', id);
	}
}

// checkIDRetrieval(string);

linSheetsController.getId(string);
