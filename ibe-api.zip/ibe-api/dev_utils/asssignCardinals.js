const rawPlayers = [
  ["Srimath Agalawatte", "Barbara McKinnon"],
  ["Bobbie Rodney", "Anna Blanchard"],
  ["Robert Teesdale", "Arni Anidjar-Romain"],
  ["Geoff Horn", "Jill Horn"],
  ["Dido Coley", "Lily Kearney"],
  ["Helen Robinson", "Karima Basse"],
  ["Kishore Jani", "Marcel Mester"],
  ["Tim Nash", "Jeff Green"],
  ["Peter Clark", "Roy Button"],
  ["Colin Holehouse", "Helen Holehouse"],
  ["Sam Mahmud", "A Player"],
  ["Jacqui Collier", "David Collier"]
];

const groups = {
  north: [],
  south: [],
  east: [],
  west: []
};

for (let i = 0; i < rawPlayers.length; i++) {
  const pair = rawPlayers[i];
  const northPlayer = pair[0];
  const southPlayer = pair[1];

  if (i % 2 === 0) {
    groups.north.push(northPlayer);
    groups.south.push(southPlayer);
  } else {
    groups.east.push(northPlayer);
    groups.west.push(southPlayer);
  }
}

console.log("north:", groups.north.join(","));
console.log("south:", groups.south.join(","));
console.log("east:", groups.east.join(","));
console.log("west:", groups.west.join(","));