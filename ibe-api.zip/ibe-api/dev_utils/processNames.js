const names = [
	'Srimath Agalawatte & Barbara McKinnon\nBobbie Rodney & Anna Blanchard\nRobert Teesdale & Arni Anidjar-Romain\nGeoff Horn & Jill Horn\nDido Coley & Lily Kearney\nHelen Robinson & Karima Basse\nKishore Jani & Marcel Mester\nTim Nash & Jeff Green\nPeter Clark & Roy Button\nColin Holehouse & Helen Holehouse\nSam Mahmud & A Player\nJacqui Collier & David Collier\n'
];

const numOfTables = 6;

let ns = [];
let ew = [];
function processNamesText(value, numOfTables) {
	let namesArray = [];
	const namesInPlay = numOfTables * 2;

	const lines = value[0]
		.split('\n')
		.filter(line => line.trim() !== '')
		.map(line => line.trim());

	console.log('lines: ', lines);

	namesArray = namesInPlay !== -1 ? lines.slice(0, namesInPlay) : lines;

	namesArray = namesArray.map(item => item.split(' & '));

	for (let i = 0; i < namesArray.length; i++) {
		console.log('pair in array: ', namesArray[i]);
		if (i % 2 === 0) {
			ns.push(namesArray[i]);
		} else {
			ew.push(namesArray[i]);
		}
	}
	const finalArray = ns.concat(ew);
	console.log('final array: ', finalArray);

	return namesArray;
}

const namesArray = processNamesText(names, numOfTables);

console.log('namesArray: ', namesArray);
console.log('ns array: ', ns);
console.log('ew array: ', ew);
