const {
	devMailService,
	devAuthConfig,
	prodAuthConfig,
	sendDetails
} = require('../src/services/mail_service');
const customError = require('../src/services/error');

const dummyError = new customError('This is a test Error', 500, {
	customData: {
		title: 'Some Title',
		custom_body: 'Some Body'
	}
});

devMailService.sendErrorMail(dummyError)