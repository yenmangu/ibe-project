const customError = require('../src/services/error');

const testError = new customError('TestError Message', 400, {
	customData: {
		title: 'Test Custom Data Title',
		custom_body: 'Test Custom Data Body'
	}
});

// const emailResult = testError.sendErrorEmail();
// emailResult.then(()=> {
// 	console.log(emailResult)
// })

async function sendErrorAndLogTiming() {
	// Start overall timer
	const startTime = process.hrtime();

	const emailResult = await testError.sendErrorMail();

	// End overall timer
	const endTime = process.hrtime(startTime);

	console.log('Email Result: ', emailResult);

	console.log('Overall execution time: %ds %dms', endTime[0], endTime[1] / 1000000);
}

sendErrorAndLogTiming();
