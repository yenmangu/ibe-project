function convertURL(inputString) {
	if (!inputString.startsWith('htt')) {
		console.log('Non Link, skipping');
		return;
	}

	if (inputString.includes('?bbo=')) {
		console.log('skipping BBO');
		return;
	}

	const step1Result = inputString.replace(/^.*\?lin=/, 'qx|o*|');

	const matchResult = inputString.match(/\|Board(%20)?(\d+)\|/);
	let boardNumber;
	if (matchResult !== null) {
		console.log('matchResult: ', matchResult);
		boardNumber = matchResult[2];
	}

	// Step 3: Replace "*" with the extracted board number
	console.log('boardNumber: ', boardNumber);
	const step3Result = step1Result.replace(/\*/, boardNumber);

	// Step 4: Replace usernames
	const usernames = inputString.match(/\|pn\|([^|]+)/)[1].split(',');
	let replacement = '|pn|south,west,north,east';

	for (let i = 0; i < usernames.length; i++) {
		replacement = replacement.replace(usernames[i], usernames[i]);
	}

	// Combine the results
	const finalResult = step3Result.replace(/\|pn\|[^|]+\|/, replacement + '|');

	// console.log(finalResult);

	return finalResult;
}

const inputString =
	'https://www.bridgebase.com/tools/handviewer.html?lin=st||pn|Ishd,ajtim,dusktodawn,swapan%20dey|md|4SQ7HT7DAT4CQJT983,SAT862HK942D98C75,SK5HAQJ653DKJ63C6,SJ943H8DQ752CAK42|sv|e|rh||ah|Board%206|mb|P|mb|1C|mb|P|mb|1H|mb|P|mb|1N|mb|P|mb|4H|mb|P|mb|P|mb|P|pc|CA|pc|C3|pc|C7|pc|C6|pc|S3|pc|S7|pc|SA|pc|SK|pc|C5|pc|H3|pc|C2|pc|C8|pc|S5|pc|S4|pc|SQ|pc|S6|pc|HT|pc|H2|pc|H5|pc|H8|pc|H7|pc|H4|pc|HJ|pc|S9|pc|HA|pc|SJ|pc|C9|pc|H9|pc|D3|pc|D5|pc|DA|pc|D9|pc|DT|pc|D8|pc|D6|pc|DQ|pc|CK|pc|CT|pc|S2|pc|H6|pc|DK|pc|D2|pc|D4|pc|S8|pc|DJ|pc|D7|';

const noSpace =
	'https://www.bridgebase.com/tools/handviewer.html?lin=st||pn|,|md|3SA932HJ964DA2CA94,SQ64HQTDJ853CQ632,SKTH73DKQ96CKJT85,SJ875HAK852DT74C7|sv|o|rh||ah|Board1|mb|1C|an|4+!C;HCP11-23;natural|mb|1H|an|5+!H;HCP8-17;natural|mb|D!|an|4!S;HCP6+;exactly4!S-Nonforcing|mb|P|an|HCP9-;weakhand|mb|2C|an|5+!C;HCP11-16;natural|mb|P|mb|3N|an|1+!C;2-4!H;4!S;HCP12-16;game,toplay|mb|P|mb|P|mb|P|pc|HQ|pc|H3|pc|H2|pc|H4|pc|HT|pc|H7|pc|HK|pc|H6|pc|HA|pc|H9|pc|C3|pc|D6|pc|D7|pc|D2|pc|D3|pc|D9|pc|CJ|pc|C7|pc|C4|pc|CQ|pc|D8|pc|DQ|pc|D4|pc|DA|mc|9|';

const output = convertURL(inputString);

console.log('output: ', output);

module.exports = { convertURL };
