# Future Implementations

## SLOT accounts.

Currently, the slot account reffers to the game ID which is also the user ID. Yes multiple games can be hosted by one user, but there is no functionality for that to happen in the current server (Victor's) set up.

This is something that will change in the future: ideally one user could
theoretically open as many slot accounts as they want and they will all be tied to that single user. We will enable slot account switching as a feature in the header/ menu bar, to allow the game director-user to instantly see the users they have within that slot account.


End player-users, will be able to see the slot they are registered in, the tyoe of game and the hand records so far.