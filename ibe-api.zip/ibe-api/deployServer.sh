#!/bin/bash

# Source and destination paths
source_path="./"  # Current directory

# Prompt for the project name
read -p "Enter the project name: " project_name

# Check if the project name is provided
if [ -z "$project_name" ]; then
    echo "Project name is required."
    exit 1
fi
echo "Deploying IBEscore api to remote:/home/ibe-api/htdocs/$project_name/"

read -n 1 -p "Press Y to continue or N to abort: " choice
echo
choice=$(echo "$choice" | tr '[:lower:]' '[:upper:]')


if [[ "$choice" == "Y" ]]; then
    echo "Continuing with deployment..."
    # Add your deployment commands here
elif [[ "$choice" == "N" ]]; then
    echo "Deployment aborted."
    exit 1
else
    echo "Invalid choice. Please press Y to continue or N to abort."
    exit 1
fi

# Construct the destination path
destination_path="ibe-api@141.136.42.220:/home/ibe-api/htdocs/$project_name/"

# # Create a temporary exclude file from .gitignore
# exclude_file=$(mktemp)

# # Filter out comments and empty lines, then format for rsync
# grep -vE '(^#|^$)' .gitignore | sed 's/^/--exclude /' > "$exclude_file"

# # Run rsync over SSH with the dynamically created exclude file
# rsync -avz --update \
#     -e "ssh -i ~/.ssh/hostinger/ibe-api_ed25519" \
#     $(cat "$exclude_file") \
#     "$source_path" "$destination_path"

# Run rsync over SSH
rsync -avz --update \
    --exclude "*.sh" \
    --exclude "*.md" \
    --exclude "request" \
    --exclude "*.rdb" \
    --exclude "node_modules" \
    --exclude "./data" \
    --exclude "dev_data" \
    --exclude "dev_utils"\
    --exclude "xml_response"\
    --exclude "uploads"\
    -e "ssh -i ~/.ssh/hostinger/ibe-api_ed25519" \
    "$source_path" "$destination_path"

# Check rsync exit status
if [ $? -eq 0 ]; then
    echo "Successfully synchronized."
    echo
    echo "Installing node modules..."
    echo
    ssh -i ~/.ssh/hostinger/ibe-api_ed25519 ibe-api@141.136.42.220 \
    "cd /home/ibe-api/htdocs/$project_name \
    && npm install"
    if [ $? -eq 0 ]; then
        echo "Successfully installed node modules"
    else
         echo "Failed to install node modules."
    fi
else
    echo "Synchronization encountered errors."
fi
