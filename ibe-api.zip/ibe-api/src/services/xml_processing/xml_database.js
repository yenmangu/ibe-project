const xml2js = require('xml2js');
const fs = require('fs').promises;
const xmlService = require('./xml_service');





// module.exports = { parseXML };
