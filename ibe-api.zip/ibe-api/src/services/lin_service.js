const fs = require('fs');
const path = requre('path');

// const filePath = path
