exports.restoreFromHistory = (data) => {
	
};
